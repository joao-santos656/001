#include <stdio.h>
        main(){
            int V, C, L, A;
            printf("Calculo de volume de um prisma retangular\n");
            printf("Medida do comprimento:");
            scanf("%d",&C);
            printf("Medida da largura:");
            scanf("%d",&L);
            printf("Medida da altura:");
            scanf("%d",&A);
            V = C * L * A;
            printf("V = %d",V);
        }
