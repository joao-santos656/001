#include <stdio.h>
int main(){
    int N, I;
    char T;
    I=1;
    T='*';
   
    printf(" Digite quantas vezes deseja repertir os asteriscos: ");
    scanf("%d",&N);
    printf("\n for:");
        for(I=1;I<=N;I++){
            printf(" %c",T);
        }
    I=1;
    printf("\n while:");
        while(I <= N){
            printf(" %c",T);
            I = I+1;
        }
    I=1;
    printf("\n Do...while:");
        do{
            I=I+1;
            printf(" %c",T);
        }
        while(I<=N);
       
}
