#include <stdio.h>
main(){
    float n1, p1, n2, p2, n3, p3, S;
    printf("Calculo de media de notas e seus pesos\n");
    printf("Nota 1:");
    scanf("%f",&n1);
    printf("Peso 1:");
    scanf("%f",&p1);
    printf("Nota 2:");
    scanf("%f",&n2);
    printf("Peso 2:");
    scanf("%f",&p2);
    printf("Nota 3:");
    scanf("%f",&n3);
    printf("Peso 3:");
    scanf("%f",&p3);
    S = (n1*p1 + n2*p2 + n3*p3)/3;
    printf("Média: %f",S);
}
