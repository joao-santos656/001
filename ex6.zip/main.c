#include <stdio.h>
int main(){
    int V =100;
    
    while(V <=300){
        int q =2;
        if(V%q!=0){
            printf("%d\n",V);
        }
    V=V+1;
    }
}