#include <stdio.h>
main(){
    int n;
    printf("Digite um número:");
    scanf("%d",&n);
    if(n>10)
    printf("\nEsse número é maior que 10!");
    else
    printf("\n");
}
