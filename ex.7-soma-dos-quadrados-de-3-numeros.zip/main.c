#include <stdio.h>
main(){
    int A, B, C, S;
    printf("Calculo da soma dos quadrados de 3 numeros\n");
    printf("1o. numero:");
    scanf("%d",&A);
    printf("2o. numero:");
    scanf("%d",&B);
    printf("3o. numero:");
    scanf("%d",&C);
    S = A*A + B*B + C*C;
    printf("Resultado:%d",S);
 
}



