#include <stdio.h>
int main(){
    int n1, n2;
        char T;
    printf("\nDigite qual será a operação(+ - / *): ");
    scanf("%s",&T);
     printf("\nDigite o 1o. número: ");
    scanf("%d",&n1);
    printf("\nDigite o 2o. número: ");
    scanf("%d",&n2);
    switch(T){
        case '+':
            printf("%d",n1+n2);
            break;
        case '-':
            printf("%d",n1-n2);
            break;
        case '/':
            printf("%d",n1/n2);
            break;
        case '*':
            printf("%d",n1*n2);
            break;
        default:
            printf("Opção inválida");
    }
}



