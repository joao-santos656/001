#include <stdio.h>
int main(){
    
    int o = 1;
    char m;
    
    while(o < 2 ){
        
        int n;
        
        printf("\n\n Digite o número referente a opção desejada:\n\n");
        printf(" 1- Números ímpares entre 100 e 300\n\n 2- Números primos até o valor informado\n\n 3- Informe dez valores, veja qual é o menor, qual é o maior e a média dos valores\n\n Opção:");
        scanf("%d",&n);
        printf("\n");
    switch(n){
        case 1:{
            
                int V =100;
    
                while(V <=300){
                int q =2;
                if(V%q!=0){
                printf("%d, ",V);
                }
                V=V+1;
                }
        }
                break;
                
        case 2:{
            
                int N, B,  Q=0;

                    printf("\n\n\n\n\n ==Programa para visualização de números primos==\n");
                    printf("\n Digite até qual número: ");
                    scanf("%d",&N);
                    printf("\n");
                for(int I = 1; I<= N; I++){
                B = 0;
    
                for(int C = 2;C<I;C++){
                    if(I % C !=0){
                B = 1;
                    }
                    else{
                    B = 0;
                    break;
                    }       
                }
                    if(B == 1||I == 2){
                    printf("%d, ",I);
                    Q++;
                    }
                }
                printf("\n\n De 1 até %d tem %d números primos\n\n\n\n\n",N,Q);
        }
                break;
                
        case 3:{
            
                    int A, B, C, D, E, F, G, H, I, J, X, Z;
                    float Y;
                        printf(" Digite os valores:\n");
                        scanf("%d",&A);
                        scanf("%d",&B);
                        scanf("%d",&C);
                        scanf("%d",&D);
                        scanf("%d",&E);
                        scanf("%d",&F);
                        scanf("%d",&G);
                        scanf("%d",&H);
                        scanf("%d",&I);
                        scanf("%d",&J);
    
                    Z=A+B+C+D+E+F+G+H+I+J;
    
                    if(Z>0)
                        Z=Z*-1;
                    else
                        Z=Z;
        
                    do{
                        Z=Z+1;
                    }
                    while(Z<A||Z<B||Z<C||Z<D||Z<E||Z<F||Z<G||Z<H||Z<I||Z<J);
                        printf("\n Maior número: %d",Z);
    
                    X=Z+1;
    
                    do{
                        X=X-1;
                    }
                    while(X>A||X>B||X>C||X>D||X>E||X>F||X>G||X>H||X>I||X>J);
                        printf("\n Menor número: %d",X);
    
                    Y=A+B+C+D+E+F+G+H+I+J;
                        printf("\n Média dos números: %f",Y/10);
        }
                        break;
    }
        printf("\n\n Deseja continuar?: se sim tecle (s), se não tecle (n)\n\n Opção: ");
        scanf("%s",&m);
        
    if(m == 's')
        o == 1;
    
    else
        break;
    }
    printf("\n Obrigado por usar o programa!");
}







