#include <stdio.h>
main (){
 float n1, n2, n3, S;
 printf("\n média de notas \n");
 printf("Informe sua 1a. nota:");
 scanf("%f",&n1);
 printf("informe sua 2a. nota:");
 scanf("%f",&n2);
 printf("informe sua 3a. nota:");
 scanf("%f",&n3);
 S = (n1 + n2 + n3)/3 ;
 printf("Sua média é: %f",S);
}

