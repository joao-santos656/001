#include <stdio.h>
int main(){
    int N;
    printf(" Digite sua idade para saber sua categoria: ");
    scanf("%d",&N);
    printf("\n Sua categoria é:\n\n ");
    (N < 5)?printf(" Invalido"):(N <= 7)?printf(" Infantil A"):(N <= 10)?printf(" Infantil B"):(N <=13)?printf(" Juvenil A"):(N <= 17)?printf(" Juvenil B"):printf(" Adulto");
}
    
