#include <stdio.h>
main (){
  float P, A, S;
  printf ("Digite seu peso:");
  scanf ("%f", &P);
  printf ("Digite sua altura:");
  scanf ("%f", &A);
    S = P / (A * A);
  if (S > 30)
	printf ("Você esta obeso");
    else if (S > 25)
	    printf ("Você esta acima do peso");
        else if (S > 18)
	        printf ("Você esta com peso normal");
            else
	            printf ("Você esta abaixo do peso");
}
