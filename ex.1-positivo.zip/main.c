#include <stdio.h>
main(){
    int N;
    printf(" Digite um número:");
    scanf("%d",&N);
    if(N<0)
    printf("\n");
    else
    printf(" %d é positivo");
}