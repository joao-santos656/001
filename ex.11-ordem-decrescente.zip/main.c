#include <stdio.h>
main(){
    int A, B, C;
    printf("Digite 3 números distintos: ");
    scanf("%d,%d,%d", &A,&B,&C);
    if(A>B && A>C){
        if(B>C)
        printf("%d - %d - %d",A,B,C);
        else if(C>B)
        printf("%d - %d - %d",A,C,B);
        else 
    printf(" Opção invalida");
    }
    if(B>A && B>C){
        if(A>C)
        printf("%d - %d - %d",B,A,C);
        else if(C>A)
        printf("%d - %d - %d",B,C,A);
        else 
    printf(" Opção invalida");
    }
    if(C>A && C>B){
         if(A>B)
        printf("%d - %d - %d",C,A,B);
        else if(B>A)
        printf("%d - %d - %d",C,B,A);
        else 
    printf(" Opção invalida");
    }
}
