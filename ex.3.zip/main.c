#include <stdio.h>
int main(){
    int C, N;
    long L;
    printf("==Calculo de fatorial==");
    printf("\n\n Valor: ");
    scanf("%d",&N);
    L=1;
    C=1;
    do{
        L=L*C;
        C=C+1;
    }
    while(C <= N);
    printf(" Fatorial: %ld",L);
}