#include <stdio.h>
main(){
    int N;
    printf("Digite um dia da semana: ");
    scanf("%d",&N);
    if(N == 7)
        printf("Esse dia é Sábado!");
        else if(N == 6)
            printf("Esse dia é Sexta-feira!");
            else if(N == 5)
                printf("Esse dia é Quinta-feira!");
                else if(N == 4)
                    printf("Esse dia é Quarta-feira!");
                    else if(N == 3)    
                        printf("Esse dia é Terça-feira!");
                        else if(N == 2)
                            printf("Esse dia é Segunda-feira!");
                            else if(N == 1)
                                printf("Esse dia é Domingo!");
                                else
                                printf("Opção inválida!");
}
