#include <stdio.h>
int main(){
    int A, B, C, D, E, F, G, H, I, J, X, Z;
    float Y;
    printf(" Digite os valores:\n ");
    scanf("%d",&A);
    scanf(" %d",&B);
    scanf(" %d",&C);
    scanf(" %d",&D);
    scanf(" %d",&E);
    scanf(" %d",&F);
    scanf(" %d",&G);
    scanf(" %d",&H);
    scanf(" %d",&I);
    scanf(" %d",&J);
    
    Z=A+B+C+D+E+F+G+H+I+J;
    
    if(Z>0)
        Z=Z*-1;
    else
        Z=Z;
        
    do{
        Z=Z+1;
    }
    while(Z<A||Z<B||Z<C||Z<D||Z<E||Z<F||Z<G||Z<H||Z<I||Z<J);
    printf("\n Maior número: %d",Z);
    
    X=Z+1;
    
    do{
        X=X-1;
    }
    while(X>A||X>B||X>C||X>D||X>E||X>F||X>G||X>H||X>I||X>J);
    printf("\n Menor número: %d",X);
    
    Y=A+B+C+D+E+F+G+H+I+J;
    printf("\n Média dos números: %f",Y/10);
}

