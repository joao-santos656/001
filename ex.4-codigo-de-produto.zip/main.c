#include <stdio.h>
int main(){
    int N;
    printf(" Digite o codigodo produto:");
    scanf("%d",&N);
    (N <= 0)?printf(" Inválido"):(N == 1)?printf(" Alimento não perecivel"):(N <= 4)?printf(" Alimento perecivel"):(N <= 6)?printf(" Vestuário"):(N == 7)?printf(" Higiene pessoal"):(N <= 15)?printf(" Limpeza e untensílios domésticos"):printf(" Inválido");
}