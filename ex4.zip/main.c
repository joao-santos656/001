#include <stdio.h>
#include <stdlib.h>
int main(){
    int N, B,  Q=0;

    printf(" ==Programa para visualização de números primos==\n");
    printf("\n Digite até qual número: ");
    scanf("%d",&N);
    printf("\n");
    for(int I = 1; I<= N; I++){
        B = 0;
    
        for(int C = 2;C<I;C++){
            if(I % C !=0){
             B = 1;
             
            }
            else{
             B = 0;
             break;
            }
        }
        if(B == 1||I == 2){
            printf("%d, ",I);
            Q++;
        }
    }
    printf("\n\n De 1 até %d tem %d números primos",N,Q);
}



