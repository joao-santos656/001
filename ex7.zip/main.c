#include <stdio.h>
int main(){
    
     int t, q = 0;
    for(int i = 1;i<=10;i++){
    
    printf(" Digite uma idade: ");
    scanf("%d",&t);
    
    if(t>17){
        t =q=q+1;
    }
    
    i=i++;
    }
    printf("\n %d pessoas tem mais de 18 anos",q);
}