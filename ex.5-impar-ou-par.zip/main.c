#include<stdio.h>
main(){
    int n;
    printf("Digite um número: ");
    scanf("%i",&n);
    if(n % 2 == 0)    
        printf("\n O número é par");

    else
        printf("\n O número é impar");
}