#include <stdio.h>
main(){
    int PI, R, S;
    printf("\n Calcule a área de um circulo\n");
    printf("Medida do raio do circulo:\n");
    scanf("%d",&R);
    PI = 3.14;
    S = PI * (R*R);
    printf("A área do circulo é:%d",S);
}


