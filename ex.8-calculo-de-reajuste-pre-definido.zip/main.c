#include <stdio.h>
main(){
    float N1, S; 
    int N2;
    printf("Valor do produto:");
    scanf("%f",&N1);
    printf("qual será o reajuste:\n");
    printf("[1]15% \n[2]20% \n[3]30% \nN:");
    scanf("%d",&N2);
    if(N2>0,N2<2)
        printf("Valor final:%f",N1+(N1*0.15));
        else if(N2>1,N2<3)
            printf("Valor final:%f",N1+(N1*0.20));
            else if(N2>2,N2<4)
                printf("Valor final:%f",N1+(N1*0.30));
                else
                printf("Opção inválida");
    
}
