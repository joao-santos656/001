#include <stdio.h>
main(){
    int n, S;
    printf("Digite seu ano de nascimento:");
    scanf("%d",&n);
    S = 2024 - n;
    if(S>=18)
        printf("Sua idade é: %d você ja pode votar e tirar sua CNH!",S);
    else if(S>=16)
        printf("Sua idade é: %d você ja pode votar!",S);
    else
        printf("Sua idade é: %d",S);
}
