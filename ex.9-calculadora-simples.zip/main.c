#include <stdio.h>
main(){
    int n1, n2, V;
    printf("Valor 1:");
    scanf("%d",&n1);
    printf("valor 2:");
    scanf("%d",&n2);
    printf("Tipo de operação: \n 1. adição \n 2. subtração \n 3. multiplicação \n 4. divisão \n N:");
    scanf("%d",&V);
    if(V>0,V<2)
        printf("Resultado:%d",n1+n2);
        else if(V>1,V<3)
            printf("Resultado:%d",n1-n2);
            else if(V>2,V<4)
                printf("Resultado:%d",n1*n2);
                else if(V>3,V<5)
                    printf("Resultado:%d",n1/n2);
                    else
                    printf("Opção Inválida");
}