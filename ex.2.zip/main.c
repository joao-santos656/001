#include <stdio.h>
int main(){
    int M, S, ST;
    M=10;
    ST=1;
    S=1;
    printf(" ==contagem regressiva==\n\n");
    while(M >= 1){
        
        printf("\n");
        while(ST >=1){
            
            ST=ST-1;
            printf("\n");
            do{
                S=S-1;
                printf("%d:%d%d,  ",M,ST,S);
            }
            while(S >= 1);
            S=10;
        }
    ST=6;
    M=M-1;
    }
}
