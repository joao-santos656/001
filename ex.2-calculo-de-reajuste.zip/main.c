#include <stdio.h>
int main(){
    float N, V, T, tot;
    int R;
    printf(" Calculo de reajuste\n");
    printf("\n Digite o preço do produto:");
    scanf("%f",&N);
    printf("Qual é a porcentagem de reajuste?:");
    printf("\n [1] 15");
    printf("\n [2] 20");
    printf("\n [3] 30");
    printf("\n Opção:");
    scanf("%d",&R);
    V = (R >= 4)?V=4:(R == 3)?V=0.3:(R == 2)?V=0.2:(R == 1)?V=0.15:V>3;
  T=N*V;
  tot=N+T;
  if(V>3,V<1)
    printf("Opção inválida");
    else
    printf("O reajuste foi de %f reais, o preço reajustado é %f",T,tot);
}



