#include <stdio.h>
main(){
    float n1, n2;
    printf("Selecione seu sexo:\n 1.Masculino\n 2.Feminino\n N:");
    scanf("%f",&n1);
    printf("Digite sua altura(metros):");
    scanf("%f",&n2);
    if(n1 == 1)
        printf("Seu peso ideal é:%f",(72.7*n2)- 58);
        else if(n1 == 2)
            printf("Seu peso ideal é:%f",(62.1*n2)-44);
}
