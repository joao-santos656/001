#include <stdio.h>
main(){
    int n;
    printf("Digite um número:");
    scanf("%d",&n);
    if(n>10)
    printf("O dobro desse número é: %d",n*2);
    else
        printf("O triplo desse número é: %d",n*3);
}