#include <stdio.h>
main(){
    float S, V, Ta;
    int Te;
    printf("Calculo de prestação atrasada\n");
    printf("Valor da prestação:");
    scanf("%f",&V);
    printf("Valor da taxa(por dia):");
    scanf("%f",&Ta);
    printf("Tempo de atraso(em dias):");
    scanf("%d",&Te);
    S = V + (V * (Ta/100) * Te);
    printf("O valor da prestação é:%f",S);
}


