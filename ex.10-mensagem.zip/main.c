#include <stdio.h>
int main(){
    int I;
    char nome[20];
    float P, A, S;
    printf("Digite seu nome:");
    scanf("%s",nome);
    printf("Digite sua idade, peso, e altura:");
    scanf("%d,%f,%f",&I,&P,&A);
    S = P/(A*A);
    printf("Olá %s, você tem %d anos, seu peso é %f e sua altura é %f portanto se IMC é %f",nome,I,P,A,S);
}

