#include <stdio.h>
main (){
  int n, S;
  printf ("\n tamanho do lado do quadrado:\n");
  scanf ("%d", &n);
  S = n * n;
  printf ("A area do quadrado C):%d", S);
}



