#include <stdio.h>
int main(){
    int I;
    float N;
    printf(" Informe o preço do produto: ");
    scanf("%f",&N);
    printf("\n Selecione a forma de pagamento:\n\n 1 - À vista em dinheiro\n 2 - À vista no cartão de credito\n 3 - Em 2x\n 4 - Em 3x\n Opção: ");
    scanf("%d",&I);
    printf("\n O valor pago será: ");
    switch(I){
        case 1:
            printf("%f",N-(N*0.1));
            break;
        case 2:
            printf("%f",N-(N*0.05));
            break;
        case 3:
            printf("%f",N);
            break;
        case 4:
            printf("%f",N+(N*0.1));
            break;
        default:
            printf("Opção invalida");
    }
}