#include <stdio.h>
main(){
    float n, S;
    printf("Reajuste de salário\n");
    printf("Digite seu salário:");
    scanf("%f",&n);
    S = n + (n*0.25);
    printf("Seu salário será reajustado para:%f",S);
}

