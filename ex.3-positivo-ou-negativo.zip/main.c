#include <stdio.h>
main(){
    int N;
    printf("Digite um número:");
    scanf("%d",&N);
    printf("Esse número é:");
    if(N<0)
    printf("Negativo");
    else
    printf("Positivo");
}

