#include<stdio.h>
main(){
    int B, A, S;
    printf("\nCalcule a area de um triangulo\n\n");
    printf("Medida da base:\n");
    scanf("%d",&B);
    printf("medida da altura:\n");
    scanf("%d",&A);
    S = B * A/2;
    printf("A area do triangulo é:%d",S);
}

